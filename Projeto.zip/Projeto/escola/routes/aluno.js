const express = require('express');
const router = express.Router();
let db = require('../utils/db.js')

router.get('/cadastro', function(req, res) {
    res.render('aluno', {});
});

module.exports = router;