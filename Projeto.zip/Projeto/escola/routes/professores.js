const express = require('express');
const router = express.Router();
let db = require('../utils/db.js')

// todas as rotas de professores
router.get('/cadastro', function(req, res) {
    res.render('professores', {});
});
  
module.exports = router;