const express = require('express');
const router = express.Router();
let db = require('../utils/db.js')

// todas as rotas de disciplinas
router.get('/cadastro', function(req, res) {
    res.render('disciplina', {});
});

module.exports = router;